function enterVault() {
  var i = 0;
  var intv = setInterval(function() {
    if (i == 0) {
      output("'Please do not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not not go in the vault.'")
    } else if (i == 1) {
      output("'This is a invention and it might kill you.'")
    } else if (i == 2) {
      output("You say, 'I want to go in.'")
    } else if (i == 3) {
      output("'What? I just said 'not' 630 times and I am very tired (because I said 'not' 630 times) and you still want to go?'")
    } else if (i == 4) {
      output("'Fine. Just go. *groans*'")
    } else if (i == 5) {
      output("The sciencetist let you...")
    } else if (i == 6) {
      output("'*groans* Don't blame me if you die! *groans*'")
    } else if (i == 7) {
      output("The sciencetist let you go...")
    } else if (i == 8) {
      output("...in the vault.")
    } else if (i == 9) {
      output("'*groans* Not in the vault! *groans* In the...'")
    } else if (i == 10) {
      output("You got in to the vault while the scientist said, '...door. What? *groans* Where are they? *groans* Why didn't they go in the door! *groans*' The scientist groaned and groaned and got out of control.")
      clearInterval(intv)
    }
    i += 1;
  }, 1000)
}
